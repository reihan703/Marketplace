/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Project1.Project1Market.services;

/**
 *
 * @author Victorio Adam
 */
public class InventorySellService {
    /*
    @Autowired
    private InventorySellRepository inventorySellRepository;
    
    @Override
    public List<InventorySell> getAll() {
        return inventorySellRepository.findAll();
        
    }

    @Override
    public void store(InventorySell inventorySell) {
        this.inventorySellRepository.save(inventorySell);
    }

    @Override
    public void delete(long user_id, long id) {
        this.inventorySellRepository.deleteById(user_id, id);
    }
    */
}
