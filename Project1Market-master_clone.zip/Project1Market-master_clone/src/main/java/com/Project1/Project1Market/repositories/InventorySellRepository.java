/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Project1.Project1Market.repositories;

/**
 *
 * @author Victorio Adam
 */
public class InventorySellRepository {
    /*
    String showInventoryProfileSell = "SELECT so FROM sell_order so WHERE so.id=?1";
    @Query(showInventoryProfileSell)
    List<InventorySell> findById(long user_id);
    
    String showInventoryAllSellProfile = "SELECT u, so FROM user u JOIN sell_order(a.phone, a.name) so ON so.user_id=?1 AND s.id=?1"; 
    @Query(showInventoryAllSellProfile)
    List<InventorySell> findById(long user_id, String phone, String name);
    
    String showInventoryAllSell = "Select so FROM sell_order so";
    @Query(showInventoryAllSell)
    List<InventorySell> findList();
    
    public void deleteById(long user_id, long id);
    */
}
