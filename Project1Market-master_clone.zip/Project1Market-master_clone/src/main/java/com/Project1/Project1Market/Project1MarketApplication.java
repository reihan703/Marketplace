package com.Project1.Project1Market;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project1MarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(Project1MarketApplication.class, args);
	}

}
