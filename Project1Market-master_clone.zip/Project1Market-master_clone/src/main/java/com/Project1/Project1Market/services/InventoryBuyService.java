/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Project1.Project1Market.services;

/**
 *
 * @author Victorio Adam
 */
public class InventoryBuyService {
    /*
    @Autowired
    private InventoryBuyRepository inventoryBuyRepository;
    
    @Override
    public List<InventoryBuy> getAll() {
        return inventoryBuyRepository.findAll();
        
    }

    @Override
    public void store(InventoryBuy inventoryBuy) {
        this.inventoryBuyRepository.save(inventoryBuy);
    }

    @Override
    public void delete(long id, long user_id) {
        this.inventoryBuyRepository.deleteById(user_id, id);
    }
    */
}
