/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Project1.Project1Market.repositories;

/**
 *
 * @author Victorio Adam
 */
public class InventoryBuyRepository {
    
    /*
    String showInventoryAllBuy = "SELECT user.phone, user.name FROM user INNER JOIN buy_order ON buy_order.user_id=?1 AND user.id=?1"; 
    @Query(showInventoryAllBuy)
    List<InventorySell> findById(long user_id, String phone, String name);
    
    String showInventoryProfileBuy = "SELECT id FROM sell_order id WHERE id=?1";
    @Query(showInventoryProfileBuy)
    List<InventoryBuy> findById(long user_id);
    
    public void deleteById(long user_id, long id);
    */
}
