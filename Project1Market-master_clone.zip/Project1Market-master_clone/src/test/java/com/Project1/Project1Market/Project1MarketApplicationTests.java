package com.Project1.Project1Market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project1MarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
